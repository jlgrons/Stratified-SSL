# Efficient Estimation and Evaluation of Prediction Rules in Semi-Supervised Settings under Stratified Sampling

Reference: https://arxiv.org/abs/2010.09443


